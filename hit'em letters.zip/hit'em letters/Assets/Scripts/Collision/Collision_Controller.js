#pragma strict
import UnityEngine.SceneManagement;
var s : GameObject;
var t : boolean;
var score : Score_Reset;
var life : Life_left;

function Start () {
	life = GameObject.FindWithTag("life").GetComponent(Life_left);
	yield WaitForSeconds(0.5);
	t  = s.GetComponent(sphere_text_1).enabled;
	score = GameObject.FindWithTag("score").GetComponent(Score_Reset);
}

function Update () {
}

function OnTriggerEnter( other : Collider)
{
	if(t == true)                                                 //if collision is with the correct ball
	{
		score.i = score.i + 1;
		SceneManager.LoadScene("Game Round");
	}
	else                                                          //if bullet collides with the wrong ball
	{
		life.i = life.i - 1;                                      //if wrong ball is hit, life decreases by 1
		GameObject.FindWithTag("empty").GetComponent(AudioSource).Play();
		if(life.i == 0)                                           //Loads scene if life becomes 0
		{
			yield WaitForSeconds(0.3);                            //A little delay for the life decreasing sound to be produced
			SceneManager.LoadScene("End Scene");
		}
	}
}