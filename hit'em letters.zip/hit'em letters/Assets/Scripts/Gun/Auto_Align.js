#pragma strict

function Start () {
	
}

function Update ()                          //To find the angle at which the gun is to be rotated so that it alligns itself in the direction of falling balls.
{
	
	var f : float = Input.GetAxisRaw("Horizontal");
	
	var x : float;
	var y : float;
	var z : float;
	if(f==1)
	{
		x = Mathf.Abs(GameObject.FindWithTag("rightsphere").transform.position.x - this.transform.position.x);          
		y = Mathf.Abs(GameObject.FindWithTag("rightsphere").transform.position.y - this.transform.position.y);         
		z=y/x;                                  																		
		z=Mathf.Atan(z);
		z = z * Mathf.Rad2Deg;
		z= (90 - z)%360;
		transform.localEulerAngles = Vector3(0,0,-z);
	}
	if(f==-1)
	{
		x = Mathf.Abs(GameObject.FindWithTag("leftsphere").transform.position.x - this.transform.position.x);
		y = Mathf.Abs(GameObject.FindWithTag("leftsphere").transform.position.y - this.transform.position.y);
		z=x/y;
		z=Mathf.Atan(z);
		z = (z * Mathf.Rad2Deg)%360;;
		transform.localEulerAngles = Vector3(0,0,z);
	}
	if(f==0)
	transform.localEulerAngles = Vector3(0,0,0);
}