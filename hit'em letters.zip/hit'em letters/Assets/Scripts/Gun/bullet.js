#pragma strict
var z : int = 1;                                      // Variable to make sure that the bullet continously moves and does not stop
var temp : int = 0;                                   // Variable to make sure that the bullet continously moves in the same direction
var bullet : GameObject;

function Start () {
}

function Update ()                                     //to find the unit vector in the direction in which the bullet has to be fired
{
	
	var f : float = Input.GetAxisRaw("Horizontal");
	
	var x : float;
	var y : float;
	var r : float;
	
	if((f==1 && (temp==0 || temp==1))|| temp==1)
	{
		
		x = Mathf.Abs(GameObject.FindWithTag("rightsphere").transform.position.x - GameObject.FindWithTag("GUN").transform.position.x);
		y = Mathf.Abs(GameObject.FindWithTag("rightsphere").transform.position.y - GameObject.FindWithTag("GUN").transform.position.y);
		r = Mathf.Sqrt(x*x + y*y);
		x = x/r;
		y = y/r;                                                                
		if(Input.GetButton("Fire1") || z==0)
		{
			temp = 1;
			z=0;
			transform.Translate(x*20*Time.deltaTime,y*20*Time.deltaTime,0);
		}
	}
	if((f==-1 && (temp==0 || temp==2))||temp==2)
	{
		
		x = Mathf.Abs(GameObject.FindWithTag("leftsphere").transform.position.x - GameObject.FindWithTag("GUN").transform.position.x);
		y = Mathf.Abs(GameObject.FindWithTag("leftsphere").transform.position.y - GameObject.FindWithTag("GUN").transform.position.y);
		r = Mathf.Sqrt(x*x + y*y);
		x = x/r;
		y = y/r;
		if(Input.GetButton("Fire1") || z==0)
		{
			temp=2;
			z=0;
			transform.Translate(-x*20*Time.deltaTime,y*20*Time.deltaTime,0);
		}
	}
	if((f==0 && (temp==0 || temp==3))||temp==3)
	if(Input.GetButton("Fire1")|| z==0)
	{
		temp = 3;
		z=0;
		transform.Translate(0,20*Time.deltaTime,0);
	}
}
