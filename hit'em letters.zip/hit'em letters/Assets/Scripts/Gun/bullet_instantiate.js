#pragma strict

var bullet : GameObject;
var t : float;                              //For calculating the Reload Time
function Start () {
	
}

function Update () {
	var x = GameObject.FindWithTag("bullet");
	if(x == null)                          //Fires a bullet only when no bullet is present in the scene
	{
		if(Input.GetButton("Fire1"))
		{
			t=0;
			Instantiate(bullet,GameObject.FindWithTag("GUN").transform.position,Quaternion.identity);
		}
	}
	t = t +  Time.deltaTime;
	if(t>1 && x!= null)                     //Destroy the bullet after 1 second, hence reload time is 1 second
    Destroy(GameObject.FindWithTag("bullet"));
}
