#pragma strict
import UnityEngine.SceneManagement;
function Start () {
	
}

function Update () {
	if(GameObject.FindWithTag("leftsphere").transform.position.y < -1.2 || GameObject.FindWithTag("midsphere").transform.position.y < -1.2 || GameObject.FindWithTag("rightsphere").transform.position.y < -1.2)
SceneManager.LoadScene("End Scene");                     //Loads END SCENE when any ball crosses the line
}
