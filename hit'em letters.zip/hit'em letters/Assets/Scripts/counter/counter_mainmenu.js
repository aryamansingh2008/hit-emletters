#pragma strict

var t:UnityEngine.UI.Text;
var count:int;

function Start () {
	count=PlayerPrefs.GetInt("TimesLaunched",0);              //Reads an entry from the registry,if there is no prior entry, then assigns 0 value to it
	count = count + 1 ;
	PlayerPrefs.SetInt("TimesLaunched",count);                //Writes an entry into the registry
}

function Update () {
	t.text ="Played "+ count.ToString() + " times";
}
