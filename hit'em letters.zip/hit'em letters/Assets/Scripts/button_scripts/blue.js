#pragma strict
import UnityEngine.SceneManagement;
var bg : background;
function Start () {
	
}

function Update () {
	
}
function LoadScene()
{
	bg = GameObject.FindWithTag("bg").GetComponent(background);
	bg.x=2;                                                             //X decides the color of the background in Game Round
	SceneManager.LoadScene("Game Round");
}