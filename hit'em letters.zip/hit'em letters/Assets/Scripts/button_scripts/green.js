#pragma strict
var bg : background ;
function Start () {
}

function Update () {
	
}
function LoadScene()
{
	bg = GameObject.FindWithTag("bg").GetComponent(background);
	bg.x=1;                             //X decides the color of the background in Game Round
	SceneManager.LoadScene("Game Round");
}