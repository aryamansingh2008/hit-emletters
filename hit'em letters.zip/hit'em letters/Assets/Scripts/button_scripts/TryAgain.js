#pragma strict

function Start () {
	
}

function Update () {
	
}
function LoadScene()
{
	SceneManager.LoadScene("Main Menu");                  //Script to Button "TRY AGAIN"      
}