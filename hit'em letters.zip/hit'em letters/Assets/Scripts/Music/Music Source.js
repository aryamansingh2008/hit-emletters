#pragma strict
import UnityEngine.SceneManagement;

function Awake()
{
	DontDestroyOnLoad(this);                          //To prevent the Main Music to be destroyed between scenes
}
function Start () {
	
}

function Update () {
	}