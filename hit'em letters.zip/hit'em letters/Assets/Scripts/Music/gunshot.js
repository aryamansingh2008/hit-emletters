#pragma strict
var a : AudioSource ;

function Start () {
	
}

function Update () {
	if(Input.GetButton("Fire1") && !GameObject.FindWithTag("bullet"))                     //Makes sound when the bullet is fired
	a.Play();                                                         
}
