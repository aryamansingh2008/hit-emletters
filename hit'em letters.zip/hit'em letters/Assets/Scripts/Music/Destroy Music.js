#pragma strict

function Start () {
	Destroy(GameObject.FindWithTag("music"));                //To destroy main music upon reaching END SCENE
}

function Update () {
	
}
