#pragma strict

var words= ['apple','balls','cat','dog','egg','fan','goat','hello','india','jug','knight','lion','monkey','nest','orange','peacock','queue','rat','sun','tree','umbrella','video','wolf','xylophone','yoyo','zebra'];

var index:int;
var t:UnityEngine.UI.Text;
var i : int;

function Start () {
	index = Mathf.Floor(Random.Range(0,26));                      //Generates a random word from the give array of strings
	i=Random.Range(0,3);                                          //Generates a random integer to determine which ball has the correct letter on it
	if(i==0)
	{
		GameObject.FindWithTag("lefttext").GetComponent(sphere_text_1).enabled=true;
		GameObject.FindWithTag("lefttext").GetComponent(sphere_text_2).enabled=false;
		GameObject.FindWithTag("righttext").GetComponent(sphere_text_1).enabled=false;
		GameObject.FindWithTag("righttext").GetComponent(sphere_text_2).enabled=true;
		GameObject.FindWithTag("midtext").GetComponent(sphere_text_1).enabled=false;
		GameObject.FindWithTag("midtext").GetComponent(sphere_text_2).enabled=true;
	}
	if(i==1)
	{
		GameObject.FindWithTag("lefttext").GetComponent(sphere_text_1).enabled=false;
		GameObject.FindWithTag("lefttext").GetComponent(sphere_text_2).enabled=true;
		GameObject.FindWithTag("righttext").GetComponent(sphere_text_1).enabled=false;
		GameObject.FindWithTag("righttext").GetComponent(sphere_text_2).enabled=true;
		GameObject.FindWithTag("midtext").GetComponent(sphere_text_1).enabled=true;
		GameObject.FindWithTag("midtext").GetComponent(sphere_text_2).enabled=false;
	}
	if(i==2)
	{
		GameObject.FindWithTag("lefttext").GetComponent(sphere_text_1).enabled=false;
		GameObject.FindWithTag("lefttext").GetComponent(sphere_text_2).enabled=true;
		GameObject.FindWithTag("righttext").GetComponent(sphere_text_1).enabled=true;
		GameObject.FindWithTag("righttext").GetComponent(sphere_text_2).enabled=false;
		GameObject.FindWithTag("midtext").GetComponent(sphere_text_1).enabled=false;
		GameObject.FindWithTag("midtext").GetComponent(sphere_text_2).enabled=true;
	}
}

function Update () {
	t.text=words[index].ToLower();
}
