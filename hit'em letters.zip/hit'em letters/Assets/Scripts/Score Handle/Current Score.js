#pragma strict
var score : Score_Reset;
var text : UI.Text;
function Start () {
	score = GameObject.FindWithTag("score").GetComponent(Score_Reset);               //Access the score from the score gameobject's script
}

function Update () {
	text.text="S c o r e : " +score.i;
}
