#pragma strict
var text : UI.Text;
var s : Score_Reset;
function Start () {
	s = GameObject.FindWithTag("score").GetComponent(Score_Reset);         //Access the score from the score gameobject's script
}

function Update () {
	text.text="Your Score was\n\"" + s.i + "\"";                           //Displays the final score
}
