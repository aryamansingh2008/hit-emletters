#pragma strict
import UnityEngine.SceneManagement;

function Start () {
	DontDestroyOnLoad(GameObject.FindWithTag("score"));          //To prevent the Score gameobject from being destroyed as the scene reloads
}

function Update () {
	if(SceneManager.GetActiveScene().name=="Main Menu")          //Resets the score to 0 when the game restarts
		GameObject.FindWithTag("score").GetComponent(Score_Reset).enabled=true;
	else
		GameObject.FindWithTag("score").GetComponent(Score_Reset).enabled=false;
}
