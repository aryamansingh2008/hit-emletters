#pragma strict
var i : int = 0;                            //Initialize the score to 0
function Start () {
	
}

function Update () {
	
}
