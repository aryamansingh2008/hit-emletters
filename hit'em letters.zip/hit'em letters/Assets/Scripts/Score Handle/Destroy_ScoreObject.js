#pragma strict

function Awake () {
	Destroy(GameObject.FindWithTag("score"));            //Destroys the score gameobject upon reaching END SCENE
}

function Update () {
	
}
