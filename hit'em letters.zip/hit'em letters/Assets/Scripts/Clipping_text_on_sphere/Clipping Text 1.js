#pragma strict
var t : UnityEngine.UI.Text;

function Start () {
	
}

function Update () {
	var xyz : Vector3 = Camera.main.WorldToScreenPoint(this.transform.position);                                 //to clip the UI text to the falling spheres
	t.transform.position = xyz;
}
