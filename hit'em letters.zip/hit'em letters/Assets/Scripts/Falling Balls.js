#pragma strict
var x:GameObject;
var f :float;
var i : int;
var scorescript : Score_Reset;
function Start () {
	scorescript=GameObject.FindWithTag("score").GetComponent(Score_Reset);
	i=scorescript.i;                        //Speed of the balls increases as the score becomes more
	if(i<3)
	f=Random.Range(0.8,1.2);                              //To make speed of balls different
	else if(i>=3 && i<6)
	f=Random.Range(1.2,1.8);
	else if(i>=6 && i<10)
	f=Random.Range(1.5,2.2);
	else if(i>=10 && i < 30)
	f=Random.Range(1.8,2.5);
	else
	f=Random.Range(2.5,3.5);
}

function Update () {
	x.transform.Translate(0,-f*Time.deltaTime,0);
}
