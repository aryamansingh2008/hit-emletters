//Give the correct letter on the ball which belongs to the randomly chosen word

#pragma strict
var words= ['apple','balls','cat','dog','egg','fan','goat','hello','india','jug','knight','lion','monkey','nest','orange','peacock','queue','rat','sun','tree','umbrella','video','wolf','xylophone','yoyo','zebra'];

var i : int ;
var j : int ;
var t : UnityEngine.UI.Text;
var s : String;
var index : Random_word;

function Start ()
{
	index = GameObject.FindWithTag("empty").GetComponent(Random_word);             //to know to correct word chosen from "Random_word" script
	i=index.index;
	j  = Random.Range(0,words[i].Length);                                          //takes a random letter from the word 
	s = words[i];
	t.text = s[j].ToString().ToLower() ;
}

function Update ()
{
}
