//To give wrong letters which don't belong to the random owrd generated

#pragma strict
var words= ['apple','balls','cat','dog','egg','fan','goat','hello','india','jug','knight','lion','monkey','nest','orange','peacock','queue','rat','sun','tree','umbrella','video','wolf','xylophone','yoyo','zebra'];

var i : int ;
var t : UnityEngine.UI.Text;
var s : String;
var alpha = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
var flag : int = 0;
var up : int = 0;
var q : int ;
var index : Random_word;

function Start()
{
	index = GameObject.FindWithTag("empty").GetComponent(Random_word);           //to know the word generated from the "Random_word" script
	i=index.index;
	s = words[i];
}

function Update ()                                                              //To generate a random letter which doesnot belong to the word generated
{
	flag=0;
	if(up == 0)
	{
		if(s.Length>2)
		{
			var k : char = Random.Range(97,122);
			for( q=0 ; q<s.Length; q++)
			{
				if(k==s[q])
				flag=1;
			}
			if(flag==0)                                                          //flag=0 tells that the random letter does not belong to the word
			{
				up=1;                                                            // up =1 tells that the random letter is found 
				t.text = k.ToString();
			}
		}
	}
}