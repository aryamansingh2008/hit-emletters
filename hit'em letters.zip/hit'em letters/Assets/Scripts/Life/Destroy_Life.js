#pragma strict

function Start () {
	Destroy(GameObject.FindWithTag("life_canvas"));           //To destroy the Life gameobject upon reaching END SCENE
}

function Update () {
	
}
