#pragma strict

var text : UI.Text;
var i : int = 3;

function Awake () {
	DontDestroyOnLoad(GameObject.FindWithTag("life_canvas"));                //To prevent the Life gameobject from destroying and restarting as the score increases on
}

function Update () {
	text.text="L i f e  : "+i;
}
