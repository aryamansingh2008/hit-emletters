#pragma strict

var rend:Renderer;
var bg : background;

function Start () {
	bg = GameObject.FindWithTag("bg").GetComponent(background);                           //To access the background color chosen and make bakcground color accordingly
	rend = GetComponent.<Renderer>();
}

function Update () {
	if(bg.x==0)
	rend.material.color=Color.red;
	if(bg.x==1)
	rend.material.color=Color.green;
	if(bg.x==2)
	rend.material.color=Color.blue;
}
