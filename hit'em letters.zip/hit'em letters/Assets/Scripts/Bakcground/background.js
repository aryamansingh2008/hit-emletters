#pragma strict

var x : int ;
function Awake () {
	DontDestroyOnLoad(this);                                //So the background game object can be accessed in the next scene "Game Round"
}

function Update () {
	
}
