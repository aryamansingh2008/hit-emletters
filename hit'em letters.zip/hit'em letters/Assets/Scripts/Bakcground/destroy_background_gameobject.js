#pragma strict

function Start () {
	Destroy(GameObject.FindWithTag("bg"));                                                              //Destroys the background gameobject upon replaying the game
}

function Update () {
	
}
